module.exports = {
    bracketSpracing: true, 
    jsxBracketSameLine: true, 
    singleQuote: true, 
    trailingComma: 'all',
};