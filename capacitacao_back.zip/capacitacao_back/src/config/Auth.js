export default {
    secret: 'HUDSKOFSO4785H$%#-$*9EFD+H867489EHDF-U32478%¨#*()@*DJD'

};