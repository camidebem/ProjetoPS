export default {
  host: 'smtp.ethereal.email',
  port: 587,
  auth: {
    user: 'imogene56@ethereal.email',
    pass: 'Czz4SRMvGkHEVcSnEb',
  },
};
